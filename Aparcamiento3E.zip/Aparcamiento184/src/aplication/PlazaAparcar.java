/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplication;

/**
 *
 * @author alumnogreibd
 */
public class PlazaAparcar extends Plaza {

    public PlazaAparcar(int codigo, TipoPlaza tipo, Aparcamiento aparcamiento) {
        super(codigo, tipo, aparcamiento);
    }
    
}
