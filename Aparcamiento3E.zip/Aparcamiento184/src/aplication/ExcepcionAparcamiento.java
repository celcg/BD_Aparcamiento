package aplication;

public class ExcepcionAparcamiento extends Exception {
    public ExcepcionAparcamiento(String mensaje) {
        super(mensaje);
    }
}
